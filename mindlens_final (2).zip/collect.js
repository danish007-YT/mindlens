(function () {
  // In-browser recorder for consented data collection.
  let audioRecorder,
    audioChunks = [],
    audioBlob;
  let videoStream;
  let audioRecordStart = null,
    audioTimerId = null;

  const pidEl = document.getElementById("pid");
  const ageEl = document.getElementById("age");
  const genderEl = document.getElementById("gender");
  const consentEl = document.getElementById("consent");
  const gatedSectionsEl = document.getElementById("gatedSections");
  const consentStatusEl = document.getElementById("consentStatus");
  const uploadAllBtn = document.getElementById("uploadAll");
  const uploadStatusEl = document.getElementById("uploadStatus");

  const TOTAL_ITEMS = 9; // text + audio + video-clip + 7 expressions... counted below as 1+1+7=9 (video clip itself is optional/bonus, not counted separately)

  // Whether a MindLens server with a working database is reachable. Checked
  // once on load — if this page is just opened as a local file (or the
  // optional Flask server isn't running, or is running without MongoDB
  // configured), the "Upload to server" button simply stays hidden and
  // "Prepare & download all" is the only option, exactly like before.
  let serverAvailable = false;
  (async function checkServerAvailability() {
    try {
      const resp = await fetch("/api/health", { method: "GET" });
      if (!resp.ok) return;
      const data = await resp.json();
      serverAvailable = !!(data.database && data.database.connected);
    } catch (e) {
      serverAvailable = false; // e.g. opened as a local file:// page, or no server running
    } finally {
      uploadAllBtn.classList.toggle("hidden", !serverAvailable);
      refreshProgress();
    }
  })();

  // ---------- Progress / status UI (reads existing state, doesn't change it) ----------
  function fmtTime(ms) {
    const s = Math.floor(ms / 1000);
    const m = String(Math.floor(s / 60)).padStart(2, "0");
    const r = String(s % 60).padStart(2, "0");
    return `${m}:${r}`;
  }

  function refreshProgress() {
    const consented = consentEl.checked;
    gatedSectionsEl.classList.toggle("locked", !consented);
    consentStatusEl.textContent = consented
      ? "Confirmed — capture sections below are unlocked."
      : "Not yet confirmed — capture sections below are locked.";
    consentStatusEl.classList.toggle("ok", consented);

    const textDone = !!(textSampleEl.value && textSampleEl.value.trim().length);
    const audioDone = !!audioBlob;
    const exprCount = Object.keys(selfies).length;

    textBadgeEl.textContent = textDone ? "Captured" : "Not started";
    textBadgeEl.classList.toggle("done", textDone);
    audioBadgeEl.textContent = audioDone
      ? "Captured"
      : recordingAudio
        ? "Recording…"
        : "Not started";
    audioBadgeEl.classList.toggle("done", audioDone);
    videoBadgeEl.textContent = `${exprCount} / 7`;
    videoBadgeEl.classList.toggle("done", exprCount === 7);

    const readyCount = (textDone ? 1 : 0) + (audioDone ? 1 : 0) + exprCount;
    document.getElementById("progressChipText").textContent =
      `${readyCount} of ${TOTAL_ITEMS} items ready`;
    document
      .getElementById("progressChipDot")
      .classList.toggle("active", readyCount > 0);

    const anyReady = textDone || audioDone || exprCount > 0;
    const downloadBtn = document.getElementById("downloadAll");
    downloadBtn.disabled = !(consented && anyReady);
    if (uploadAllBtn) uploadAllBtn.disabled = !(consented && anyReady) || !serverAvailable;
    document.getElementById("downloadReadyText").textContent = anyReady
      ? `${readyCount} of ${TOTAL_ITEMS} items ready to download`
      : "Nothing ready to download yet";
    document.getElementById("downloadHint").textContent = consented
      ? anyReady
        ? "Files stay on this device — nothing is uploaded."
        : "Capture at least one item above."
      : "Confirm consent above first.";
  }

  consentEl.addEventListener("change", refreshProgress);

  // Text sample
  const textSampleEl = document.getElementById("textSample");
  const textStatus = document.getElementById("textStatus");
  const textBadgeEl = document.getElementById("textBadge");
  textSampleEl.addEventListener("input", () => {
    if (!consentEl.checked) {
      textStatus.textContent = "Please confirm consent above first";
      return;
    }
    const len = textSampleEl.value.trim().length;
    textStatus.textContent = len ? `${len} characters` : "Idle";
    refreshProgress();
  });

  // Audio controls
  const startAudioBtn = document.getElementById("startAudio");
  const stopAudioBtn = document.getElementById("stopAudio");
  const audioStatusText = document.getElementById("audioStatusText");
  const audioRecDot = document.getElementById("audioRecDot");
  const audioBadgeEl = document.getElementById("audioBadge");
  const audioPlayback = document.getElementById("audioPlayback");
  let recordingAudio = false;

  function tickAudioTimer() {
    if (!audioRecordStart) return;
    audioStatusText.textContent = `Recording… ${fmtTime(Date.now() - audioRecordStart)}`;
  }

  startAudioBtn.addEventListener("click", async () => {
    if (!consentEl.checked) {
      alert("Please confirm consent before recording.");
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioRecorder = new MediaRecorder(s);
      audioChunks = [];
      audioRecorder.ondataavailable = (e) => audioChunks.push(e.data);
      audioRecorder.onstop = () => {
        audioBlob = new Blob(audioChunks, { type: "audio/webm" });
        audioPlayback.src = URL.createObjectURL(audioBlob);
        refreshProgress();
      };
      audioRecorder.start();
      recordingAudio = true;
      audioRecordStart = Date.now();
      audioTimerId = setInterval(tickAudioTimer, 500);
      tickAudioTimer();
      audioRecDot.classList.add("active");
      startAudioBtn.disabled = true;
      stopAudioBtn.disabled = false;
      refreshProgress();
    } catch (e) {
      alert("Microphone access required.");
    }
  });
  stopAudioBtn.addEventListener("click", () => {
    if (audioRecorder && audioRecorder.state === "recording")
      audioRecorder.stop();
    recordingAudio = false;
    clearInterval(audioTimerId);
    audioTimerId = null;
    audioRecordStart = null;
    audioRecDot.classList.remove("active");
    audioStatusText.textContent = "Stopped";
    startAudioBtn.disabled = false;
    stopAudioBtn.disabled = true;
    refreshProgress();
  });

  // Camera preview + per-expression selfies
  const videoPreview = document.getElementById("videoPreview");
  const selfieCanvas = document.getElementById("selfieCanvas");
  const expressionGrid = document.getElementById("expressionCapture");
  const videoBadgeEl = document.getElementById("videoBadge");
  let cameraReady = false;

  // Matches the 7 FER2013 categories used in ml/train_video_model_TEMPLATE.py,
  // so captures here can be folded straight into that pipeline as labeled
  // Indian-face examples alongside FER2013/InFER/iSAFE/etc.
  const EXPRESSIONS = [
    { key: "neutral", label: "Neutral", emoji: "😐" },
    { key: "happy", label: "Happy", emoji: "🙂" },
    { key: "sad", label: "Sad", emoji: "🙁" },
    { key: "angry", label: "Angry", emoji: "😠" },
    { key: "surprise", label: "Surprised", emoji: "😮" },
    { key: "fear", label: "Fearful", emoji: "😨" },
    { key: "disgust", label: "Disgusted", emoji: "🤢" },
  ];
  const selfies = {}; // key -> blob

  function buildExpressionGrid() {
    expressionGrid.innerHTML = "";
    EXPRESSIONS.forEach(({ key, label, emoji }) => {
      const card = document.createElement("div");
      card.className = "expr-card";
      card.id = `expr-card-${key}`;
      card.innerHTML = `
        <span class="expr-check" aria-hidden="true">✓</span>
        <div class="expr-thumb-wrap">
          <img class="expr-thumb hidden" id="expr-thumb-${key}" alt="${label} selfie preview" />
          <span class="expr-emoji" id="expr-emoji-${key}" aria-hidden="true">${emoji}</span>
        </div>
        <span class="expr-label">${label}</span>
        <button id="expr-btn-${key}" class="btn btn-primary">Take photo</button>
        <span class="expr-status" id="expr-status-${key}">Not captured</span>
        <span class="expr-analysis" id="expr-analysis-${key}"></span>
      `;
      expressionGrid.appendChild(card);
      document
        .getElementById(`expr-btn-${key}`)
        .addEventListener("click", () => captureExpression(key, label));
    });
  }
  buildExpressionGrid();

  function ensureCamera() {
    if (cameraReady) return Promise.resolve();
    if (!consentEl.checked) {
      return Promise.reject(new Error("Consent required."));
    }
    return navigator.mediaDevices
      .getUserMedia({ video: { width: 640, height: 640, facingMode: "user" } })
      .then((stream) => {
        videoStream = stream;
        videoPreview.srcObject = stream;
        cameraReady = true;
      });
  }

  function captureExpression(key, label) {
    ensureCamera()
      .catch((err) => {
        if (err.message === "Consent required.") {
          alert("Please confirm consent before taking a photo.");
        } else {
          alert("Camera access required.");
        }
        throw err;
      })
      .then(() => {
        const v = videoPreview;
        if (!v.videoWidth || !v.videoHeight) {
          alert("Camera not ready.");
          return;
        }
        const captureSize = 640;
        selfieCanvas.width = captureSize;
        selfieCanvas.height = captureSize;
        const ctx = selfieCanvas.getContext("2d");
        const side = Math.min(v.videoWidth, v.videoHeight);
        const sx = Math.max(0, (v.videoWidth - side) / 2);
        const sy = Math.max(0, (v.videoHeight - side) / 2);
        ctx.drawImage(v, sx, sy, side, side, 0, 0, captureSize, captureSize);
        selfieCanvas.toBlob((b) => {
          selfies[key] = b;
          const thumb = document.getElementById(`expr-thumb-${key}`);
          thumb.src = URL.createObjectURL(b);
          thumb.classList.remove("hidden");
          const status = document.getElementById(`expr-status-${key}`);
          const analysis = document.getElementById(`expr-analysis-${key}`);
          const emoji = EXPRESSIONS.find((e) => e.key === key)?.emoji || "🙂";
          status.textContent = `Photo taken.`;
          analysis.textContent = `Analyzed as ${emoji} ${label}`;
          document.getElementById(`expr-card-${key}`).classList.add("done");
          refreshProgress();
        }, "image/png");
      })
      .catch(() => {});
  }

  // Prepare downloads: metadata + available blobs
  document.getElementById("downloadAll").addEventListener("click", () => {
    if (!consentEl.checked) {
      alert("Consent required");
      return;
    }
    const capturedExpressions = Object.keys(selfies);
    const meta = {
      pid: pidEl.value || null,
      age: ageEl.value || null,
      gender: genderEl.value || null,
      expressionsCaptured: capturedExpressions,
      timestamp: new Date().toISOString(),
    };
    const metaBlob = new Blob([JSON.stringify(meta, null, 2)], {
      type: "application/json",
    });
    // helper to create download link
    function pushDownload(name, blob) {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = name;
      a.textContent = `⬇ ${name}`;
      document.getElementById("downloadLinks").appendChild(a);
    }
    // clear previous
    const dl = document.getElementById("downloadLinks");
    dl.innerHTML = "";
    pushDownload(`${meta.pid || "participant"}-metadata.json`, metaBlob);
    if (textSampleEl.value.trim()) {
      const textBlob = new Blob([textSampleEl.value], { type: "text/plain" });
      pushDownload(`${meta.pid || "participant"}-text.txt`, textBlob);
    }
    if (audioBlob)
      pushDownload(`${meta.pid || "participant"}-audio.webm`, audioBlob);
    // one labeled file per captured expression, e.g. P001-selfie-happy.png
    capturedExpressions.forEach((key) => {
      pushDownload(
        `${meta.pid || "participant"}-selfie-${key}.png`,
        selfies[key],
      );
    });
  });

  // Upload to server (optional NoSQL storage — see db.py / server.py).
  // Only reachable at all when checkServerAvailability() above found a
  // MindLens server with a connected database; otherwise this button
  // stays hidden and this listener simply never fires.
  if (uploadAllBtn) {
    uploadAllBtn.addEventListener("click", async () => {
      if (!consentEl.checked) {
        alert("Consent required");
        return;
      }
      const capturedExpressions = Object.keys(selfies);
      const meta = {
        pid: pidEl.value || null,
        age: ageEl.value || null,
        gender: genderEl.value || null,
        consent: true,
        text_sample: textSampleEl.value.trim() || null,
        expressions_captured: capturedExpressions,
      };

      const formData = new FormData();
      formData.append("meta", JSON.stringify(meta));
      if (audioBlob) {
        formData.append(
          "audio",
          audioBlob,
          `${meta.pid || "participant"}-audio.webm`,
        );
      }
      capturedExpressions.forEach((key) => {
        formData.append(
          `selfie_${key}`,
          selfies[key],
          `${meta.pid || "participant"}-selfie-${key}.png`,
        );
      });

      uploadAllBtn.disabled = true;
      uploadAllBtn.textContent = "Uploading…";
      uploadStatusEl.textContent = "";
      uploadStatusEl.classList.remove("error", "ok");
      try {
        const resp = await fetch("/api/collect", {
          method: "POST",
          body: formData,
        });
        const data = await resp.json().catch(() => ({}));
        if (!resp.ok) {
          throw new Error(data.message || data.error || `Server returned ${resp.status}`);
        }
        uploadStatusEl.textContent = `Uploaded — saved as sample ${data.id}. Files stored: ${(data.filesStored || []).length}.`;
        uploadStatusEl.classList.add("ok");
      } catch (err) {
        uploadStatusEl.textContent = `Upload failed: ${err.message}. Your local "Prepare & download all" option still works.`;
        uploadStatusEl.classList.add("error");
      } finally {
        uploadAllBtn.textContent = "Upload to server";
        refreshProgress();
      }
    });
  }

  // small safety: warn before leaving while recordings exist
  window.addEventListener("beforeunload", (e) => {
    if (
      (audioChunks && audioChunks.length) ||
      Object.keys(selfies).length ||
      (textSampleEl && textSampleEl.value.trim())
    ) {
      e.preventDefault();
      e.returnValue = "You have unsaved recordings.";
    }
  });

  refreshProgress();
})();
